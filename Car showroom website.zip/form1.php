<body>
<?php
$con=mysql_connect("mysql.cis.ksu.edu",cis_id,"password);
if(!$con)
	{
		die("could not connect:'.mysql_error());
}
mysql_select_db("cis_id",$con);
$sql="Insert INTO nmaetable(First Name,Last Name,Phone Number,email)
VALUES
('$=POST[First Name]','$_POST[Last Name]','$_POST[Phone Number]','$_POST[email]');
if(!mysql_query($sql,$con))
{
die('ERROR:'.mysql_error());
}
echo "Your record is added";
mysql_close($con)
?>
</body>
</html>
